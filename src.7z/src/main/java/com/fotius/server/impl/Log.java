package com.fotius.server.impl;

import java.util.logging.Logger;

/**
 * Created with IntelliJ IDEA.
 * User: vvinnik
 * Date: 11/12/13
 * Time: 6:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class Log {

}
