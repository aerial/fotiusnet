package com.fotius.shared.model;

import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: vvinnik
 * Date: 10/29/13
 * Time: 5:42 PM
 * To change this template use File | Settings | File Templates.
 */
public interface UserRole {
}
